Overview
The purpose of this project to learn and practice web developing tools like PHP, Javascript and HTML/css.
You can view the live webpage of this project at 
https://junlingtest.000webhostapp.com
On this primitive-looking page I tried various ways to interact between a browser and a server database.
And these techniques are used to develop this page:
https://junlingtest.000webhostapp.com/gogame/
which is a online Go game.

Hosting
This project is hosted on 000webhost.
https://www.000webhost.com/
This is a free hosting service.
All the files and folders in the folder sould be put in the
public_html folder in server.

junling-wang@hotmail.com
密码 2013加密（杏仁桉，00）
database name JL
DB username JL id302411_JL
DB pasword 2013加密（杏仁桉，00）
