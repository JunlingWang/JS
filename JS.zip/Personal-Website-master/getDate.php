<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php echo(Date("l F d, Y , s"));?>
</body>
</html>